import { Injectable } from '@nestjs/common';

@Injectable()
export class OrderService {
  //create new order
  //get single order
  //get logged in user orders and admin
  //admin update/process order
  //admin delete order
}
