import { Injectable } from '@nestjs/common';

@Injectable()
export class ProductService {
  //create new product
  //get all products admin and user
  //single product
  //update product
  //delete product
}
